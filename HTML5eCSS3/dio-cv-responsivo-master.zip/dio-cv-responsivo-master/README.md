# CV Responsivo - Live DIO - Trabalhando com responsividade na prática

[![Twitter URL](https://img.shields.io/twitter/url/https/twitter.com/theleoad.svg?style=social&label=%20%40theleoad)](https://twitter.com/theleoad)

Esse repositório foi criado para a Live do Bootcamp Impulso React Web Developer da Digital Innovation One.

![AnVIL Image](./img/readme-bootcamp-image.png 'Bootcamp Impulso React Web Developer')

---

# Ferramentas utilizadas

Ícones do projeto: [Font Awesome](https://fontawesome.com/)  
Imagens placeholder: [Lorem Picsum](https://picsum.photos/)  
Gerador de paleta de cores: [Coolors](https://coolors.co)  
Gerador de favicon: [Favicon.io](https://link-url-here.org)  
Editor de Texto: [VS Code](https://code.visualstudio.com/)  
Extensão para servir as páginas localmente: [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer)  
Navegador: [Firefox Developer Edition](https://www.mozilla.org/pt-BR/firefox/developer/)
